package com.beans;

public class GiveFeedbackBean {
private String uid,feedback,da;

public String getDa() {
	return da;
}

public void setDa(String da) {
	this.da = da;
}

public String getUid() {
	return uid;
}

public void setUid(String uid) {
	this.uid = uid;
}

public String getFeedback() {
	return feedback;
}

public void setFeedback(String feedback) {
	this.feedback = feedback;
}
}
