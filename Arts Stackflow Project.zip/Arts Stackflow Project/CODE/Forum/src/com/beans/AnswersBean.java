package com.beans;

public class AnswersBean {
private String date,answers;

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getAnswers() {
	return answers;
}

public void setAnswers(String answers) {
	this.answers = answers;
}
}
