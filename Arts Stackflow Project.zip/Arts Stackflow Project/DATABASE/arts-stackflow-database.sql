/*
SQLyog Community v8.71 
MySQL - 5.5.30 : Database - qna
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`qna` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `qna`;

/*Table structure for table `answers` */

DROP TABLE IF EXISTS `answers`;

CREATE TABLE `answers` (
  `ID` varchar(11) DEFAULT NULL,
  `OID` varchar(255) DEFAULT NULL,
  `Questions` varchar(1000) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `UID` varchar(255) DEFAULT NULL,
  `Answers` varchar(2000) DEFAULT NULL,
  `Date2` varchar(255) DEFAULT NULL,
  `Status3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `answers` */

insert  into `answers`(`ID`,`OID`,`Questions`,`Date`,`UID`,`Answers`,`Date2`,`Status3`) values ('1','ahmed@gmail.com','what is architecture?','Sat','ibraheem@gmail.com','the art or practice of designing and constructing buildings:','Sat Feb 12 19:05:24 IST 2022','Open'),('1','ahmed@gmail.com','what is architecture?','Sat','ibraheem@gmail.com','the complex or carefully designed structure of something:','Sat Feb 12 19:06:38 IST 2022','Open'),('1','ahmed@gmail.com','what is architecture?','Sat','rafi@gmail.com','the expression or application of human creative skill and imagination, typically in a visual form such as painting or sculpture, producing works to be appreciated primarily for their beauty or emotional power:','Mon Feb 14 11:17:07 IST 2022','Open'),('2','ibraheem@gmail.com','Dance comes under arts ?','Sat','rafi@gmail.com','Theatrical dance, also called performance or concert dance, is intended primarily as a spectacle, usually a performance upon a stage by virtuoso dancers. ','Mon Feb 14 11:17:19 IST 2022','Closed'),('4','rafi@gmail.com','What are the different forms of Art?','Mon','ahmed@gmail.com','Among the earliest forms of art, painting may be traced back to tens of thousands of years ago and is found in caves in numerous locations across the world, including the Drakensberg, the Northern Territory, and the Lascaux paintings in France.','Mon Feb 14 11:22:28 IST 2022','Closed'),('4','rafi@gmail.com','What are the different forms of Art?','Mon','ibraheem@gmail.com','Painting, sculpture, architecture, literature, music, film, and theater are all forms of art. ','Mon Feb 14 11:24:31 IST 2022','Closed'),('5','Ravi@gmail.com','What is Arts ?','Thu','ibraheem@gmail.com','the expression or application of human creative skill and imagination, typically in a visual form such as painting or sculpture, producing works to be appreciated primarily for their beauty or emotional power:','Thu Nov 17 12:23:43 IST 2022','Closed');

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `FID` int(11) NOT NULL AUTO_INCREMENT,
  `Uid` varchar(255) DEFAULT NULL,
  `Feedback` varchar(1000) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `feedback` */

insert  into `feedback`(`FID`,`Uid`,`Feedback`,`Date`) values (1,'ahmed@gmail.com','Nice my all questions are solved','Mon Feb 14 11:39:04 IST 2022'),(2,'rafi@gmail.com','valuable information we got','Mon Feb 14 11:39:55 IST 2022'),(3,'ibraheem@gmail.com','Nice Information','Mon Feb 14 11:40:30 IST 2022'),(4,'Ravi@gmail.com','Experience good.','Thu Nov 17 12:27:16 IST 2022');

/*Table structure for table `unauthorised` */

DROP TABLE IF EXISTS `unauthorised`;

CREATE TABLE `unauthorised` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) DEFAULT NULL,
  `Status1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `unauthorised` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Mobile` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Status7` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`Name`,`Email`,`Mobile`,`Password`,`Status7`) values ('Ahmed','ahmed@gmail.com','9876543210','1234','Authorised'),('Ibraheem','ibraheem@gmail.com','9876543210','1234','Authorised'),('rafi','rafi@gmail.com','9876543210','1234','Authorised'),('Ravi','Ravi@gmail.com','81213235745','1234','Authorised');

/*Table structure for table `writequestions` */

DROP TABLE IF EXISTS `writequestions`;

CREATE TABLE `writequestions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UID` varchar(255) DEFAULT NULL,
  `Questions` varchar(1000) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Status1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `writequestions` */

insert  into `writequestions`(`ID`,`UID`,`Questions`,`Date`,`Status1`) values (1,'ahmed@gmail.com','what is architecture?','Sat Feb 12 19:02:25 IST 2022','Open'),(2,'ibraheem@gmail.com','Dance comes under arts ?','Sat Feb 12 19:05:02 IST 2022','Closed'),(3,'rafi@gmail.com','What are the different forms of Art?','Mon Feb 14 11:16:50 IST 2022','Closed'),(4,'rafi@gmail.com','What are the different forms of Art?','Mon Feb 14 11:21:17 IST 2022','Closed'),(5,'Ravi@gmail.com','What is Arts ?','Thu Nov 17 12:10:17 IST 2022','Closed');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
